﻿Imports System.Data.SqlClient
Imports System.Configuration

Public Class UsrrLogin
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnLogin.Click
        If txtUsername.Text = "" Or txtPassword.Text = "" Or ddlRole.SelectedValue = "" Then
            lblMessage.Text = "All fields are required."
            Return
        End If

        Dim conStr As String = ConfigurationManager.ConnectionStrings("EmployeeDB").ConnectionString
        Using con As New SqlConnection(conStr)
            Dim query As String = "SELECT COUNT(*) FROM loginmaster WHERE EmpID=@EmpID AND password=@Password AND userrole=@Role"
            Using cmd As New SqlCommand(query, con)
                cmd.Parameters.AddWithValue("@EmpID", txtUsername.Text.Trim())
                cmd.Parameters.AddWithValue("@Password", txtPassword.Text.Trim())
                cmd.Parameters.AddWithValue("@Role", ddlRole.SelectedValue)

                con.Open()
                Dim result As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                con.Close()

                If result > 0 And ddlRole.SelectedItem.Text.ToString().Equals("Admin") Then
                    Session("Userid") = txtUsername.Text
                    Session("Role") = ddlRole.SelectedValue
                    Response.Redirect("/Admin/AdminDashboard.aspx")
                ElseIf result > 0 And ddlRole.SelectedItem.Text.ToString().Equals("Employee") Then
                    Session("Userid") = txtUsername.Text
                    Session("Role") = ddlRole.SelectedValue
                    Response.Redirect("UserDashboard.aspx")
                Else
                    lblMessage.Text = "Invalid username, password or role."
                End If
            End Using
        End Using
    End Sub
End Class