﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Public Class Deleteemp
    Inherits System.Web.UI.Page
    Dim conn As SqlConnection = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=D:\bcaproject\OneStopEmployeeSelfService\ESSdb001.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            'Dim empID As String = Request.QueryString("id") ' Pass ID via query string

            LoadEmployee()
            DropDownListEmployeeID.Items.Insert(0, "----Select Employee ID-----")

        End If
    End Sub
    Private Sub LoadEmployee()
        Try
            conn.Open()
            Dim adpt As SqlDataAdapter = New SqlDataAdapter("select *from EmployeeMastertbl", conn)
            Dim ds As DataSet = New DataSet()
            adpt.Fill(ds)
            If ds.Tables(0).Rows.Count > 0 Then
                DropDownListEmployeeID.DataSource = ds
                DropDownListEmployeeID.DataTextField = "EmpID"
                DropDownListEmployeeID.DataValueField = "EmpiD"
                DropDownListEmployeeID.DataBind()
            End If

        Catch ex As Exception
            lblMessage.Text = "Error: " & ex.Message
        Finally
            conn.Close()
        End Try
    End Sub


    Protected Sub btnLogout_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnLogout.Click
        Session.Clear()
        Response.Redirect("/UserLogin.aspx")
    End Sub

    Protected Sub btnDelteEmployee_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDelteEmployee.Click
        conn.Open()
        Dim query As String = "delete from EmployeeMastertbl where EmpID=@EmpID"

        Using cmd As New SqlCommand(query, conn)
            ' Add parameters from form controls
            cmd.Parameters.AddWithValue("@EmpID", DropDownListEmployeeID.SelectedItem.ToString())

            Try

                cmd.ExecuteNonQuery()

                lblMessage.Text = "Employee Deleted successfully!"
                lblMessage.ForeColor = Drawing.Color.Green

            Catch ex As Exception
                lblMessage.Text = "Error: " & ex.Message
                lblMessage.ForeColor = Drawing.Color.Red
            End Try
        End Using
    End Sub

    Protected Sub DropDownListEmployeeID_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles DropDownListEmployeeID.SelectedIndexChanged
        Try
            conn.Open()
            Dim eid As Integer = Integer.Parse(DropDownListEmployeeID.SelectedItem.ToString())
            Dim adpt As SqlDataAdapter = New SqlDataAdapter("SELECT * FROM EmployeeMastertbl where EmpID=" & eid, conn)
            Dim ds As DataSet = New DataSet()
            adpt.Fill(ds)
            If ds.Tables(0).Rows.Count > 0 Then
                txtName.Text = ds.Tables(0).Rows(0)("EmpName")
                txtDesignation.Text = ds.Tables(0).Rows(0)("Designation")
                txtEmail.Text = ds.Tables(0).Rows(0)("Email")
                txtContact.Text = ds.Tables(0).Rows(0)("Contact")
                ddlDepartment.SelectedItem.Text = ds.Tables(0).Rows(0)("Department")

            End If

        Catch ex As Exception
            lblMessage.Text = "Error: " & ex.Message
        Finally
            conn.Close()
        End Try
    End Sub

    Protected Sub btnGo_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnGo.Click
        Session.Clear()
        Response.Redirect("~/Admin/AdminDashboard.aspx")
    End Sub
End Class