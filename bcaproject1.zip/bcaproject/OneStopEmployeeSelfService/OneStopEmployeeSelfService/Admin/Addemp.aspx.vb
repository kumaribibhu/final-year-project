﻿Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class GlobalVariables
    Public Shared eid As Integer
End Class
Public Class Addemp
    Inherits System.Web.UI.Page
    Dim con As SqlConnection = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=D:\bcaproject\OneStopEmployeeSelfService\ESSdb001.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            'Dim empID As String = Request.QueryString("id") ' Pass ID via query string

            getempId()

        End If


    End Sub
   
    Public Sub getempId()

        Try
            con.Open()
            Dim adpt As SqlDataAdapter = New SqlDataAdapter("SELECT TOP (1) id, EmpID FROM EmployeeMastertbl ORDER BY id DESC", con)
            Dim ds As DataSet = New DataSet()
            adpt.Fill(ds)
            If ds.Tables(0).Rows.Count > 0 Then
                GlobalVariables.eid = ds.Tables(0).Rows(0)("EmpID")
                GlobalVariables.eid += 1
                txtEmpId.Text = GlobalVariables.eid.ToString()
            End If

        Catch ex As Exception
            lblMessage.Text = "Error: " & ex.Message
        Finally
            con.Close()
        End Try

    End Sub
    Protected Sub btnAddEmployee_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAddEmployee.Click

        ' Connection string (update if needed)
        ' Dim conStr As String = @"Data Source=.\SQLEXPRESS;AttachDbFilename="C:\Users\Anurag Singh\OneDrive\Documents\ESSdb001.mdf";Integrated Security=True;Connect Timeout=30;User Instance=True"

        con.Open()
        Dim query As String = "INSERT INTO EmployeeMastertbl (EmpID, EmpName, Department, Designation, Email, Contact) " &
                                 "VALUES (@EmpID, @EmpName, @Department, @Designation, @Email, @Contact)"

        Dim query2 As String = "INSERT INTO loginmaster (EmpID,password,userrole) VALUES (@EmpID,@password, @userrole)"
        Dim cmd As SqlCommand = New SqlCommand(query, con)
        Dim cmd2 As SqlCommand = New SqlCommand(query2, con)
        ' Add parameters from form controls
        cmd.Parameters.AddWithValue("@EmpID", txtEmpId.Text.Trim())
        cmd.Parameters.AddWithValue("@EmpName", txtEmpName.Text.Trim())
        cmd.Parameters.AddWithValue("@Department", txtEmpDept.Text.Trim())
        cmd.Parameters.AddWithValue("@Designation", txtEmpDesignation.Text.Trim())
        cmd.Parameters.AddWithValue("@Email", txtEmpEmail.Text.Trim())
        cmd.Parameters.AddWithValue("@Contact", txtContact.Text.Trim())

        cmd2.Parameters.AddWithValue("EmpID", txtEmpId.Text.Trim())
        cmd2.Parameters.AddWithValue("password", TextBoxPassword.Text)
        cmd2.Parameters.AddWithValue("userrole", ddlRole.SelectedItem.ToString())

        Try

            cmd.ExecuteNonQuery()
            cmd2.ExecuteNonQuery()
            lblMessage.Text = "User added successfully!"

            lblMessage.ForeColor = Drawing.Color.Green
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "Confirmation", "User added successfully!")

            ClearForm()

        Catch ex As Exception
            lblMessage.Text = "Error: " & ex.Message
            lblMessage.ForeColor = Drawing.Color.Red
        End Try

    End Sub

    ' Optional: Clear all fields
    Private Sub ClearForm()
        txtEmpId.Text = ""
        txtEmpName.Text = ""
        txtEmpDept.Text = ""
        txtEmpDesignation.Text = ""
        txtEmpEmail.Text = ""
        txtContact.Text = ""
    End Sub

    
    Protected Sub txtEmpId_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtEmpId.TextChanged
     
    End Sub

    Protected Sub btnLogout_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnLogout.Click
        Session.Clear()
        Response.Redirect("/UserLogin.aspx")
    End Sub

    Protected Sub btnGoDash_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnGoDash.Click
        Session.Clear()
        Response.Redirect("~/Admin/AdminDashboard.aspx")
    End Sub
End Class
