﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Public Class EmployeeAttendanceReport
    Inherits System.Web.UI.Page
    Dim conn As SqlConnection = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=D:\bcaproject\OneStopEmployeeSelfService\ESSdb001.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadEmployee()
        End If
    End Sub
    Public Sub LoadEmployee()
        Try
            conn.Open()
            Dim adpt As SqlDataAdapter = New SqlDataAdapter("select *from EmployeeAttendance", conn)
            Dim ds As DataSet = New DataSet()
            adpt.Fill(ds)
            If ds.Tables(0).Rows.Count > 0 Then
                GridViewLeaveReport.DataSource = ds
                GridViewLeaveReport.DataBind()
            End If

        Catch ex As Exception

        Finally
            conn.Close()
        End Try
    End Sub

   
End Class