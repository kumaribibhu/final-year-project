﻿Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class EmployeeMissedPunched
    Inherits System.Web.UI.Page
    Dim con As SqlConnection = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=D:\bcaproject\OneStopEmployeeSelfService\ESSdb001.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSubmit.Click
        con.Open()
        Dim query As String = "INSERT INTO EmployeePunchtbl (EmployeeName,  MissedDate,  MissedTime,  PunchType, Reason) " &
                                 "VALUES (@EmployeeName, @MissedDate, @MissedTime, @PunchType, @Reason)"


        Dim cmd As SqlCommand = New SqlCommand(query, con)
        ' Add parameters from form controls
        cmd.Parameters.AddWithValue("@EmployeeName", txtEmployeeName.Text.Trim())
        cmd.Parameters.AddWithValue("@MissedDate", txtMissedDate.Text.Trim())
        cmd.Parameters.AddWithValue("@MissedTime", txtMissedTime.Text.Trim())
        cmd.Parameters.AddWithValue("@PunchType", ddlPunchType.Text.Trim())
        cmd.Parameters.AddWithValue("@Reason", txtReason.Text.Trim())


     

        Try

            cmd.ExecuteNonQuery()
            lblMessage.Text = "Employee added successfully!"

            lblMessage.ForeColor = Drawing.Color.Green
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "Confirmation", "Employee added successfully!")

            ClearForm()

        Catch ex As Exception
            lblMessage.Text = "Error: " & ex.Message
            lblMessage.ForeColor = Drawing.Color.Red
        End Try

    End Sub

    ' Optional: Clear all fields
    Private Sub ClearForm()
        txtEmployeeName.Text = ""
        txtMissedDate.Text = ""
        txtMissedTime.Text = ""
        ddlPunchType.Text = ""
        txtReason.Text = ""


    End Sub
End Class