﻿Public Class EmployeeAttendanceDashboard
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            GlobalVariables2.uid = Session("Userid").ToString()
        End If
    End Sub

    Protected Sub btnMarkAttendance_Click(sender As Object, e As EventArgs) Handles btnMarkAttendance.Click
        Response.Redirect("/EmployeeAttendance/EmployeeMarkAttendance.aspx")
    End Sub
End Class