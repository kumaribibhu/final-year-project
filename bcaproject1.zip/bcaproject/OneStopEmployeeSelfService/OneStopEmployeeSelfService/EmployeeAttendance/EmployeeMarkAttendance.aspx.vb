﻿Imports System
Imports System.IO
Imports System.Web.UI
Imports System.Data.SqlClient
Imports System.Configuration

Public Class EmployeeMarkAttendance
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            proofImage.Attributes("accept") = "image/*"
            proofImage.Attributes("capture") = "camera"
        End If
    End Sub

    Protected Sub btnSubmitAttendance_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSubmitAttendance.Click
        Try
            Dim selectedDate As String = attendanceDate.Text
            Dim selectedTime As String = attendanceTime.Text

            If Not proofImage.HasFile Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "alertMessage", "alert('Please upload an image using your camera.');", True)
                Exit Sub
            End If

            Dim fileName As String = Path.GetFileName(proofImage.FileName)
            Dim savePath As String = Server.MapPath("~/Uploads/" & fileName)
            proofImage.SaveAs(savePath)
            Dim conStr As String = ConfigurationManager.ConnectionStrings("EmployeeDB").ConnectionString
            Using con As New SqlConnection(conStr)
                Dim cmd As New SqlCommand("INSERT INTO EmployeeAttendance (EmpID,AttendanceDate, AttendanceTime,ImagePath,inout) VALUES (@EmpID, @Date, @Time, @ImagePath,@inout)", con)
                Dim strid As String = Session("Userid").ToString()
                cmd.Parameters.AddWithValue("@EmpID", strid)
                cmd.Parameters.AddWithValue("@Date", selectedDate)

                cmd.Parameters.AddWithValue("@Time", selectedTime)
                cmd.Parameters.AddWithValue("@inout", DropDownListInout.SelectedItem.Text)
                cmd.Parameters.AddWithValue("@ImagePath", "~/Uploads/" & fileName)
                con.Open()
                cmd.ExecuteNonQuery()
            End Using

            ' Show success message
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "alertMessage", "alert('Attendance submitted successfully!');", True)


        Catch ex As Exception

        End Try
    End Sub
  
End Class