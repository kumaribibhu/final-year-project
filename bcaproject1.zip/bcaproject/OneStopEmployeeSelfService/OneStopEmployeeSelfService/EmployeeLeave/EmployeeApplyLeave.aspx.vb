﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization
Public Class GlobalVariables3
    Public Shared day As Integer
End Class
Public Class EmployeeApplyLeave
    Inherits System.Web.UI.Page

    Dim con As SqlConnection = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=D:\bcaproject\OneStopEmployeeSelfService\ESSdb001.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            getempDetails()
        End If
    End Sub
    Public Sub getempDetails()

        Try
            con.Open()
            Dim Query As String = "SELECT *FROM EmployeeMastertbl where EmpID=@EmpID"
            Dim cmd As SqlCommand = New SqlCommand(Query, con)
            cmd.Parameters.AddWithValue("@EmpID", Session("Userid").ToString())
            Dim ds As DataSet = New DataSet()
            Dim adpt As SqlDataAdapter = New SqlDataAdapter(cmd)
            adpt.Fill(ds)
            If ds.Tables(0).Rows.Count > 0 Then
                employeeId.Text = ds.Tables(0).Rows(0)("EmpID")
                employeeName.Text = ds.Tables(0).Rows(0)("EmpName")
                designation.Text = ds.Tables(0).Rows(0)("Designation")
                TextBoxDepartment.Text = ds.Tables(0).Rows(0)("Department")
                contactNumber.Text = ds.Tables(0).Rows(0)("Contact")


            End If

        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Confirmation", ex.Message, True)
        Finally
            con.Close()
        End Try

    End Sub
    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSubmit.Click
        con.Open()
        Dim query As String = "INSERT INTO EmployeeApplytbl (EmployeeId,  EmployeeName,  Designation,  Department, ContactNumber, AltConNum, LeaveType, StartDate, EndDate, TotalDays, reason) " &
                                 "VALUES (@EmployeeId,  @EmployeeName,  @Designation,  @Department, @ContactNumber, @AltConNum, @LeaveType, @StartDate, @EndDate, @TotalDays, @reason) "


        Dim cmd As SqlCommand = New SqlCommand(query, con)
        ' Add parameters from form controls
        cmd.Parameters.AddWithValue("@EmployeeId", employeeId.Text.Trim())
        cmd.Parameters.AddWithValue("@EmployeeName", employeeName.Text.Trim())
        cmd.Parameters.AddWithValue("@Designation", designation.Text.Trim())
        cmd.Parameters.AddWithValue("@Department", TextBoxDepartment.Text.Trim())
        cmd.Parameters.AddWithValue("@ContactNumber", contactNumber.Text.Trim())
        cmd.Parameters.AddWithValue("@AltConNum", altContactNumber.Text.Trim())
        cmd.Parameters.AddWithValue("@LeaveType", leaveType.Text.Trim())

        Dim i As TimeSpan = New TimeSpan(0, 0, 0)
        Dim startDate As DateTime = Convert.ToDateTime(Me.startDate.Text.Trim(), New CultureInfo("en-Gb"))
        Dim endDate As DateTime = Convert.ToDateTime(Me.endDate.Text.Trim(), New CultureInfo("en-Gb"))
        i += endDate.Subtract(startDate)
        Dim days As Integer = i.Days + 1
        cmd.Parameters.AddWithValue("@StartDate", startDate)
        cmd.Parameters.AddWithValue("@EndDate", endDate)
        GlobalVariables3.day = days.ToString()
        cmd.Parameters.AddWithValue("@TotalDays", days.ToString())
        cmd.Parameters.AddWithValue("@reason", reason.Text.Trim())

        Try

            cmd.ExecuteNonQuery()

            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Confirmation", "alert('Leave Applied')", True)
            ClearForm()

        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Confirmation", ex.Message, True)

        End Try

    End Sub

    ' Optional: Clear all fields
    Private Sub ClearForm()
        employeeId.Text = ""
        employeeName.Text = ""
        designation.Text = ""
        TextBoxDepartment.Text = ""
        contactNumber.Text = ""
        altContactNumber.Text = ""
        leaveType.Text = ""
        startDate.Text = ""
        endDate.Text = ""

        reason.Text = ""



    End Sub

    Protected Sub endDate_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles endDate.TextChanged

    End Sub
End Class