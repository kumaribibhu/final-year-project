﻿Imports System.Data.SqlClient

Public Class EmpAttendDashboad
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnMarkAttendance_Click(ByVal sender As Object, ByVal e As EventArgs)
        Response.Redirect("MarkAttendance.aspx")
    End Sub

    Protected Sub btnReport_Click(ByVal sender As Object, ByVal e As EventArgs)
        Response.Redirect("Report.aspx")
    End Sub

End Class