﻿Imports System
Imports System.IO
Imports System.Web.UI
Imports System.Data.SqlClient


Public Class MarkAttendace
    Inherits System.Web.UI.Page

    Dim script As String

   
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub


    Protected Sub btnLogout_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnLogout.Click
        Session.Clear()
        Response.Redirect("/UserLogin.aspx")
    End Sub

    Protected Sub btnGoDash_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnGoDash.Click
        Session.Clear()
        Response.Redirect("~/EmployeeAttendance/EmployeeAttendanceMain.aspx")
    End Sub

    Protected Sub SubmitAttendance_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSubmitAttendance.Click
        Try
            Dim selectedDate As String = Request.Form("attendanceDate")
            Dim selectedTime As String = Request.Form("attendanceTime")
            Dim uploadedFile As HttpPostedFile = Request.Files("proofImage")

            If String.IsNullOrEmpty(selectedDate) OrElse String.IsNullOrEmpty(selectedTime) Then
                ClientScript.RegisterStartupScript(Me.GetType(), "Select Date and Time", script, True)
                Return
            End If

            If uploadedFile Is Nothing OrElse uploadedFile.ContentLength = 0 Then
                ClientScript.RegisterStartupScript(Me.GetType(), "Image format is not valid", script, True)
                Return
            End If

            ' Save the uploaded image
            Dim savePath As String = Server.MapPath("~/Uploads/")
            If Not Directory.Exists(savePath) Then
                Directory.CreateDirectory(savePath)
            End If

            Dim fileName As String = Path.GetFileName(uploadedFile.FileName)
            Dim fullPath As String = Path.Combine(savePath, fileName)
            uploadedFile.SaveAs(fullPath)

            ' Save to database
            Dim con As SqlConnection = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=D:\bcaproject\OneStopEmployeeSelfService\ESSdb001.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")
            Dim query As String = "INSERT INTO EmployeeAttendance (AttendanceDate, AttendanceTime, ProofImagePath) " &
                                       "VALUES (@Date, @Time, @ImagePath)"

            Dim cmd As SqlCommand = New SqlCommand(query, con)


            cmd.Parameters.AddWithValue("@Date", selectedDate)
            cmd.Parameters.AddWithValue("@Time", selectedTime)
            cmd.Parameters.AddWithValue("@ImagePath", "~/Uploads/" & fileName)

            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            

            ClientScript.RegisterStartupScript(Me.GetType(), "Added Successfully", script, True)

        Catch ex As Exception
            ClientScript.RegisterStartupScript(Me.GetType(), ex.Message, script, True)
        End Try
    End Sub
End Class