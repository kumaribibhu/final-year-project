﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Public Class Recordemp
    Inherits System.Web.UI.Page
    Dim conn As SqlConnection = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=D:\bcaproject\OneStopEmployeeSelfService\ESSdb001.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            'Dim empID As String = Request.QueryString("id") ' Pass ID via query string

            LoadEmployee()

        End If
    End Sub
    Private Sub LoadEmployee()
        Try
            conn.Open()
            'EmployeeMastertbl
            Dim adpt As SqlDataAdapter = New SqlDataAdapter("SELECT * FROM EmployeeMastertbl", conn)
            Dim ds As DataSet = New DataSet()
            adpt.Fill(ds)
            If ds.Tables(0).Rows.Count > 0 Then
                GridViewReportemp.DataSource = ds
                GridViewReportemp.DataBind()
            End If

        Catch ex As Exception

        Finally
            conn.Close()
        End Try
    End Sub

    Protected Sub btnLogout_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnLogout.Click
        Session.Clear()
        Response.Redirect("/UserLogin.aspx")
    End Sub

    Protected Sub btnGo_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnGo.Click
        Session.Clear()
        Response.Redirect("~/Admin/AdminDashboard.aspx")
    End Sub
End Class