﻿Imports System
Imports System.Data
Imports System.Data.SqlClient



Public Class AdminLogin
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnLogin.Click
        Dim conn As SqlConnection = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Anurag Singh\OneDrive\Documents\ESSdb001.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")
        conn.Open()
        Dim cmd As SqlCommand = New SqlCommand("select * from Admlogtbl where username=@username and password=@password", conn)
        cmd.Parameters.AddWithValue("username", txtUsername.Text.Trim())
        cmd.Parameters.AddWithValue("password", txtPassword.Text.Trim())
        Dim adpt As SqlDataAdapter = New SqlDataAdapter(cmd)
        Dim ds As DataSet = New DataSet()
        adpt.Fill(ds)
        If ds.Tables(0).Rows.Count > 0 Then
            Session("admin") = txtUsername.Text
            Response.Redirect("AdminDashboard.aspx")
        Else
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "alert", "Invalid User")

        End If

    End Sub
End Class