﻿Public Class EmployeeLeaveDashboard
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            GlobalVariables2.uid = Session("Userid").ToString()
        End If
    End Sub

    Protected Sub BtnApply_Click1(ByVal sender As Object, ByVal e As EventArgs) Handles BtnApply.Click
        Session("Userid") = GlobalVariables2.uid
        Response.Redirect("/EmployeeLeave/EmployeeApplyLeave.aspx")
    End Sub
End Class