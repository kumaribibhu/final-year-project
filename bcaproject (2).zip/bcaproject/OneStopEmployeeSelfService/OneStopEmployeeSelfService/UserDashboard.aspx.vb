﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Public Class GlobalVariables2
    Public Shared uid As String
End Class
Public Class UserDashboard
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            GlobalVariables2.uid = Session("Userid").ToString()
        End If

    End Sub

    Protected Sub btnAttendance_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAttendance.Click
        Session("Userid") = GlobalVariables2.uid
        Response.Redirect("/EmployeeAttendance/EmployeeAttendanceDashboard.aspx")

    End Sub

    Protected Sub btnLeave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnLeave.Click
        Session("Userid") = GlobalVariables2.uid
        Response.Redirect("/EmployeeLeave/EmployeeLeaveDashboard.aspx")
    End Sub

    Protected Sub btnPerformance_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnPerformance.Click

    End Sub

    Protected Sub btnReport_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnReport.Click

    End Sub
End Class