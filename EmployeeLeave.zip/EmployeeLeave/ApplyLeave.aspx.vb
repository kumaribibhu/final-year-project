﻿Imports System
Imports System.Data
Imports System.Data.SqlClient


Public Class ApplyLeave
    Inherits System.Web.UI.Page
    Dim con As SqlConnection = New SqlConnection("Data Source= Data Source=.\SQLEXPRESS;AttachDbFilename=D:\bcaproject\OneStopEmployeeSelfService\ESSdb001.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

        End If


    End Sub
    
  

End Class